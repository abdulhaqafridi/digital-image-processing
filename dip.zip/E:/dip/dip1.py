import numpy as np
import cv2
import matplotlib.pyplot as plt
img=cv2.imread('Fig0220(a)(chronometer 3692x2812  2pt25 inch 1250 dpi).tif',0)
cv2.imshow('img',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
