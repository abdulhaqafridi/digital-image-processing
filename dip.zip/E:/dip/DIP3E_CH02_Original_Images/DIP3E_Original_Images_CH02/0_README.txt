**********************************************************

     Regarding Book Image Posted in the Book Web Site

**********************************************************

Only original images in tif format are posted in the Image 
Database section of the book web site.  These are the images
that you have just downloaded. No processed images, line
drawings, or other types of graphics are posted. The idea
is that posting the original images provides the necessary
starting point to duplicate any image processing results  
in the book that are based on those images.

The Classromm PowerPoint presentations (see Faculty tab in the
book web site) do include ALL art in the book, but the resolution
is not as good as with the original,individual images in the
Image  Database section of the book web site.

